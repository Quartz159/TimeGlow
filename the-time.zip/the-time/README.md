# the time

A Pen created on CodePen.

Original URL: [https://codepen.io/Khaled-Quartz/pen/MYYpRpX](https://codepen.io/Khaled-Quartz/pen/MYYpRpX).

